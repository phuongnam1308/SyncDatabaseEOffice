// config/tablesIncomingDocuments.js
const tableMappings = {
  incomingdocument: {
    oldTable: 'VanBanDen',
    oldSchema: 'dbo',
    oldDatabase: process.env.OLD_DB_NAME,

    newTable: 'incomming_documents',
    newSchema: 'dbo',
    newDatabase: process.env.NEW_DB_NAME,

    fieldMapping: {
      'ID': 'id_incoming_bak',
      'SoDen': 'to_book_code',            // Dùng để tra book_document_id
      // 'CoQuanGui2': 'CoQuanGui2',
      // 'CoQuanGuiText': 'CoQuanGuiText',
      // 'DonVi': 'DonVi',
      // 'IsLibrary': 'IsLibrary',
      'DoKhan': 'urgency_level',
      'DoMat': 'private_level',
      // 'ThoiHanGQ': 'deadline_reply',
      // 'ItemVBDTCT': 'ItemVBDTCT',
      // 'ItemVBPH': 'ItemVBPH',
      // 'BanLanhDao': 'BanLanhDao',
      // 'LanhDaoTCT': 'LanhDaoTCT',
      // 'LanhDaoTCTDaXuLy': 'LanhDaoTCT',
      // 'LanhDaoTCTDeBiet': 'LanhDaoTCT',
      // 'LanhDaoVPDN': 'LanhDaoTCT',
      // 'LinhVuc': 'LinhVuc',
      'LoaiVanBan': 'document_type',
      'NgayDen': 'receive_date',
      'NgayTrenVB': 'to_book_date',
      // 'SoBan': 'SoBan',
      // 'SoTrang': 'SoTrang',
      'SoVanBan': 'to_book',
      // 'TrangThai': 'TrangThai',
      'TrichYeu': 'abstract_note',
      // 'VanBanTraLoi': 'VanBanTraLoi',
      // 'ChenSo': 'ChenSo',
      // 'YKienLanhDao': 'YKienLanhDao',
      // 'YKienLanhDaoTCT': 'YKienLanhDaoTCT',
      // 'YKienLanhDaoVPDN': 'YKienLanhDaoVPDN',
      // 'YKienCuaLDVPChoVanThu': 'YKienCuaLDVPChoVanThu',
      // 'ForwardType': 'ForwardType',
      'Modified': 'updated_at',
      'Created': 'created_at',
      // 'ModifiedBy': 'ModifiedBy',
      // 'CreatedBy': 'CreatedBy',
      // 'ModuleId': 'ModuleId',
      // 'SiteName': 'SiteName',
      // 'ListName': 'ListName',
      // 'ItemId': 'ItemId',
      // 'MigrateFlg': 'MigrateFlg',
      // 'YearMonth': 'YearMonth',
      // 'MigrateErrFlg': 'MigrateErrFlg',
      // 'MigrateErrMess': 'MigrateErrMess',
      // 'DGPId': 'DGPId'
    },

    requiredFields: ['abstract_note'],

    defaultValues: {
      'document_id': () => require('uuid').v4().toUpperCase(),
      'status': 1,
      'status_code': '100',               // Mặc định 100 như yêu cầu
      'book_document_id': null,           // Sẽ update sau khi tra cứu SoDen
      'created_at': function() { return new Date(); },
      'updated_at': function() { return new Date(); }
    },

    handleDuplicateId: true,
    backupIdField: 'id_incoming_bak'
  }
};

module.exports = { tableMappings };